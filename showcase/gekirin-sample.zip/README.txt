逆鱗 — 動かない龍

このZIPを展開し、editor.htmlをブラウザで開きます。ネット接続は不要です。
「ファイル」→「プロジェクトを開く」で、同じフォルダのproject.jsonを選びます。
「ガイド」をオフにして再生してください。レイヤーや範囲を編集し、別名で保存できます。
loop.gif / loop.apngは無限ループ。pv-source.mp4は6秒の作品素材です。
strip_one.jsonは鱗ひとつ、strip_row.jsonは鱗の帯の編集用プロジェクトです。

作者：unco3
出典：https://github.com/unco3/illusion-paint
制作協力：Codex × Claude Code
錯視はIllusion Paintのレンダラーで書き出しています。形状の位置は固定です。
見え方の強さは人や表示環境で変わります。逆向き探索の範囲は未確認のため無効にしています。

editor.htmlのコードはMIT、サンプル・画像・動画はCC BY 4.0です。
利用・改変・商用利用を許可します。再配布時はLICENSE、LICENSE-CC-BY-4.0.txt、
NOTICEを同梱し、サンプルを改変した場合はその旨を記載してください。
配布サンプルを流用せず自分で描いた新作には、作者へのクレジットは不要です。
